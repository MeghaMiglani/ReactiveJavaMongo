package casa.trans.mongo.enquiry.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Configuration
@ConfigurationProperties(prefix = "grafana")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class GrafanaConfig {

	private String serviceId; 
	private String subSystem; 
	private String interfaceMap;
	private String type; 
	private String functionalMap; 
	private String requestType; 
	
}
