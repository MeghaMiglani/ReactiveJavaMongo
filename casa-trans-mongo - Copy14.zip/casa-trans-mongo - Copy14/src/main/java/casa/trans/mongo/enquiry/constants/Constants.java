package casa.trans.mongo.enquiry.constants;

public class Constants {

	public static final String AUTHORIZATION = "Authorization";
	public static final String CLIENTID = "ReqClientId";
	public static final String MODE = "Mode";
	public static final String CORRELATION_ID = "CorrelationId";
	
	public static final String CA_DBS  = "CA_DBS" ; 
	public static final String CA_POSB = "CA_POSB" ; 
	public static final String DQ_DBS  = "DQ_DBS" ; 
	public static final String DQ_POSB = "DQ_POSB" ; 
	public static final String AN_DBS  = "AN_DBS" ; 
}
