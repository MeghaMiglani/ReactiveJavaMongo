/*==========================================================================================*/
/* Program Title	: Transaction Enquiry Of All Systems - DQ AN CA           				*/
/* @Author			: Sreenivasa Sama / Megha Miglani                       				*/
/* @Date Written	: 19-08-2021										    				*/
/* @Function		: Transaction Details Enquiry through mongo DB 	Database            	*/
/* @HTTP Operation  : POST / GET     														*/
/* @Endpoint		:                                                                       */
/*==========================================================================================*/
/*  @Amendments                                                             				*/
/*==========================================================================================*/
package casa.trans.mongo.enquiry.controller;

import java.time.Instant;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.ResponseEntity;

import casa.trans.mongo.enquiry.constants.Constants;
import casa.trans.mongo.enquiry.domain.Request;
import casa.trans.mongo.enquiry.domain.ResponseBody;
import casa.trans.mongo.enquiry.exception.RestError;
import casa.trans.mongo.enquiry.log.GrafanaLogger;
import casa.trans.mongo.enquiry.service.TransactionService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;

@RestController
@Slf4j
@Api(value = "CASA Transaction History enquiry", tags = {"CASA Transaction History"})
@RequestMapping("/transactions")
public class TransactionsRestController {

	private Instant start;
	
	@Autowired
	TransactionService transactionService;
	
	@Autowired
	private GrafanaLogger grafanaLogger; 

	/* Get the transaction details on basis of account number and transaction dates */
	@PostMapping(value = "/request",  produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiResponses(value = {
	            @ApiResponse(code = 200, message = "Success", response = ResponseBody.class),
	            @ApiResponse(code = 500, message = "Failure to retrieve transaction details due to system error", response = RestError.class),
	            @ApiResponse(code = 400, message = "Input validation errors", response = RestError.class)
	    })
	@ApiOperation(value = "Get CASA Transaction Details", notes = "Get CASA Transaction Details")
	public ResponseEntity<Object> getItemByAccountNumberAndDate(@RequestHeader HttpHeaders headers,
			@Valid @RequestBody Request request)
	{	
		start = Instant.now(); 
		/** Set up default response if the transaction details are not found */ 
		ResponseBody response = setDefaultResponseIfEmpty(request);
		
		String correlationId = headers.getFirst(Constants.CORRELATION_ID);
		Flux<ResponseBody> transDetailsWithInDateRange = 
				transactionService.getTransDetailsWithInDateRange(request, start, correlationId)
								.defaultIfEmpty(response);
		ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(transDetailsWithInDateRange, HttpStatus.OK);
		log.info("response from app: {}", responseEntity.toString());
		Instant end = Instant.now();
		log.info("Time taken for end to end txn is: {}ms", (end.toEpochMilli() - start.toEpochMilli()), correlationId);
		grafanaLogger.info("", HttpStatus.OK.toString(), "", start, correlationId);
		return responseEntity; 
	}

	private ResponseBody setDefaultResponseIfEmpty(Request request) {

		ResponseBody response = new ResponseBody();
		response.setAccountNumber(request.getAccountNumber());
		response.setAccountType(request.getAccountType());
		response.setCurrencyCode(request.getCurrencyCode());
		response.setPageNumber(request.getPageNumber());
		response.setCountPerPage(request.getCountPerPage());
		response.setLastKey(request.getLastKey());
		if (StringUtils.isBlank(request.getLastKey())) {
			response.setReturnMessage("No records found for this request");
		} else {
			response.setReturnMessage("No more records !!");
		}
		return response;
	}

	/* to check the cores of our application */
	@GetMapping("/cores")
	public ResponseEntity<Integer> availableCores(){
		return new ResponseEntity<Integer>(Runtime.getRuntime().availableProcessors(), HttpStatus.OK);
	}
	
	/* to check the health of our application */
	@GetMapping("/live")
	public ResponseEntity<?> live(){
		return new ResponseEntity<Object>(HttpStatus.OK);
	}

}
