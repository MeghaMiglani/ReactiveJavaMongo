/*==========================================================================================*/
/* Program Title	: Transaction Enquiry Of All Systems - DQ AN CA           				*/
/* @Author			: Sreenivasa Sama / Megha Miglani                       				*/
/* @Date Written	: 19-08-2021										    				*/
/* @Function		: Transaction Details Enquiry through mongo DB 	Database            	*/
/* @HTTP Operation  : POST / GET     														*/
/* @Endpoint		:                                                                       */
/*==========================================================================================*/
/*  @Amendments                                                             				*/
/*==========================================================================================*/
package casa.trans.mongo.enquiry.domain;

import java.util.Date;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Min;
import javax.validation.constraints.Max;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Request {

	@NotNull(message = "Not a valid account number")
	private String accountNumber;

 	@NotNull(message = "Not a valid account type")
	private String accountType;

	@NotNull(message = "Not a valid from date")
	private Date fromDate;

	@NotNull(message = "Not a valid to date")
	private Date toDate;

	@NotNull(message = "Not a valid currency code")
	private String currencyCode;
	
	private int pageNumber; 
	
	@Min(1)
	@Max(100)
	private int countPerPage;

	private String lastKey;

}
