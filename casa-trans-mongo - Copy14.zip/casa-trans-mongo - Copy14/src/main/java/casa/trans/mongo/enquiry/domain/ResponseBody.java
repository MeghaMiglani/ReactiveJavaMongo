/*==========================================================================================*/
/* Program Title	: Transaction Enquiry Of All Systems - DQ AN CA           				*/
/* @Author			: Sreenivasa Sama / Megha Miglani                       				*/
/* @Date Written	: 19-08-2021										    				*/
/* @Function		: Transaction Details Enquiry through mongo DB 	Database            	*/
/* @HTTP Operation  : POST / GET     														*/
/* @Endpoint		:                                                                       */
/*==========================================================================================*/
/*  @Amendments                                                             				*/
/*==========================================================================================*/
package casa.trans.mongo.enquiry.domain;

import java.math.BigDecimal;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResponseBody {

	private String accountType;
	private String currencyCode;
	private String accountNumber;
	private String fileSequenceNumber;
	private Date transactionDate;
	private Date postingDate;
	private String branchOfTransaction;
	private String transactionTime;
	private Date valueDate;
	private BigDecimal transactionAmount;
	private String currencyDecimal;
	private String transactionReference;
	private String transactionCode;
	private String transactionCodeOriginal;
	private String reference1;
	private String reference2;
	private String reference3;
	private String statementCode;
	private String clearingIndicator;
	private String systemId;
	private String errorCorrectionIndicator;
	private String validTransactionIndicator;

	// ** Pagination Details
	private String lastKey;
	private int pageNumber;
	private int countPerPage;
	
	// ** return message if no records found or for last page
	private String returnMessage;

}
