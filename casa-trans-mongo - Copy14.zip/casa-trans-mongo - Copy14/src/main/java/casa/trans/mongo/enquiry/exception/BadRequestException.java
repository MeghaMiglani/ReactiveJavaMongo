package casa.trans.mongo.enquiry.exception;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;
import lombok.Getter;
import lombok.Setter;

@SuppressWarnings("serial")
@ResponseStatus(code = HttpStatus.BAD_REQUEST)
@Getter
@Setter
public class BadRequestException extends RuntimeException{

	private RestError restError;
	private Instant startTime; 

	public BadRequestException() {
		super("Bad Request");
		this.restError = new RestError(HttpStatus.BAD_REQUEST, "9999", "PROCESSING_ERROR", "Bad request",
				null, LocalDateTime.now(ZoneOffset.UTC));
		this.startTime = Instant.now(); 
	}

	public BadRequestException(RestError restError, Instant startTime) {
		super(restError.getErrorDescription());
		this.restError = restError;
		this.startTime = startTime; 
	}

}
