package casa.trans.mongo.enquiry.exception;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.codec.DecodingException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.support.WebExchangeBindException;

import org.springframework.web.server.handler.ResponseStatusExceptionHandler;

import casa.trans.mongo.enquiry.constants.Constants;
import casa.trans.mongo.enquiry.log.GrafanaLogger;
import lombok.extern.slf4j.Slf4j;

@ControllerAdvice
@RestController
@Slf4j
public class CustomizedExceptionHandler extends ResponseStatusExceptionHandler {

	@Autowired
	private GrafanaLogger grafanaLogger;

	/** Handle input validations and throw Bad request exception */ 
	
	@ExceptionHandler(BadRequestException.class)
	public final ResponseEntity<Object> handleBadRequestMethod(BadRequestException badRequestException) {
		
		log.error("Bad Request {} , Correlation ID : {} ", badRequestException.getRestError()
				,badRequestException.getRestError().getCorrelationId());
		grafanaLogger.error(badRequestException.getRestError().getErrorType(),
				badRequestException.getRestError().getStatus().toString(),
				badRequestException.getRestError().getErrorCode(), badRequestException.getStartTime(),
				badRequestException.getRestError().getCorrelationId());
		
		return new ResponseEntity<Object>(badRequestException.getRestError(), HttpStatus.BAD_REQUEST);
	}
	
	/** Handle JSON format errors in request */ 
	
	@ExceptionHandler(DecodingException.class)
	public final ResponseEntity<Object> handleJsonDecodingExceptionMethod(DecodingException ex, ServerHttpRequest httpRequest) {
		RestError restError = new RestError();

		restError.setTimeStamp(LocalDateTime.now(ZoneOffset.UTC));
		restError.setErrorDescription(ex.getLocalizedMessage());
		if (ex.getLocalizedMessage().contains("Validation")) {
			restError.setStatus(HttpStatus.BAD_REQUEST);
			restError.setErrorType("VALIDATION_ERROR");
			restError.setErrorCode("9997");
		} else {
			restError.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			restError.setErrorType("PROCESSING_ERROR");
			restError.setErrorCode("9999");
		}

		restError.setCorrelationId(httpRequest.getHeaders().getFirst(Constants.CORRELATION_ID));
		log.error("JSON error {} ", restError);
		grafanaLogger.error(restError.getErrorType(), restError.getStatus().toString(), 
				restError.getErrorCode(), Instant.now(), httpRequest.getHeaders().getFirst(Constants.CORRELATION_ID));
		return new ResponseEntity<Object>(restError, restError.getStatus());
	}
	
	/** Handle default input validations mentioned in Request.class through annotations(e.g. @NotNull) */ 
	
	@ExceptionHandler(WebExchangeBindException.class)
	public final ResponseEntity<Object> handleMethodArgumentNotValid(WebExchangeBindException ex, ServerHttpRequest httpRequest) {
		RestError restError = new RestError();
		restError.setTimeStamp(LocalDateTime.now(ZoneOffset.UTC));
		restError.setErrorDescription(ex.getLocalizedMessage());
		if (ex.getLocalizedMessage().contains("Validation")) {
			restError.setStatus(HttpStatus.BAD_REQUEST);
			restError.setErrorType("VALIDATION_ERROR");
			restError.setErrorCode("9997");
		} else {
			restError.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			restError.setErrorType("PROCESSING_ERROR");
			restError.setErrorCode("9999");
		}
		
		String correlationId = httpRequest.getHeaders().getFirst(Constants.CORRELATION_ID); 
		restError.setCorrelationId(correlationId);
		log.error("Input validation error {} ", restError);
		grafanaLogger.error(restError.getErrorType(), restError.getStatus().toString(), 
				restError.getErrorCode(), Instant.now(), correlationId);
		return new ResponseEntity<Object>(restError, restError.getStatus());
	 
	}

}
