/*==========================================================================================*/
/* Program Title	: Transaction Enquiry Of All Systems - DQ AN CA           				*/
/* @Author			: Sreenivasa Sama / Megha Miglani                       				*/
/* @Date Written	: 19-08-2021										    				*/
/* @Function		: Transaction Details Enquiry through mongo DB 	Database            	*/
/* @HTTP Operation  : POST / GET     														*/
/* @Endpoint		:                                                                       */
/*==========================================================================================*/
/*  @Amendments                                                             				*/
/*==========================================================================================*/
package casa.trans.mongo.enquiry.exception;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RestError {
    private HttpStatus status; 
    private String errorCode; 
    private String errorType;
    private String errorDescription;
    private String correlationId; 
    private LocalDateTime timeStamp; 
}