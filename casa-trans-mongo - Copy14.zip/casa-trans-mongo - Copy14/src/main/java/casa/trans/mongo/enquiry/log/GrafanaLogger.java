package casa.trans.mongo.enquiry.log;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import casa.trans.mongo.enquiry.config.GrafanaConfig;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class GrafanaLogger  {

	@Autowired
	private GrafanaConfig grafanaConfig; 
	
    private static final Gson gson = new GsonBuilder().registerTypeAdapter(Instant.class, new InstantSerializer()).create();

    public GrafanaLogger() {
    }

    public void info(String errorType, String status, String errorCode, Instant startTime, String correlationId) {
        String formattedLog = formatLog(errorType , status, errorCode, startTime, correlationId);
        log.info("{}", formattedLog);
    }

    public void warn(String errorType, String status, String errorCode, Instant startTime, String correlationId) {
        String formattedLog = formatLog(errorType , status, errorCode, startTime, correlationId);
        log.warn("{}", formattedLog);
    }

    public void error(String errorType, String status, String errorCode, Instant startTime, String correlationId) {
        String formattedLog = formatLog(errorType , status, errorCode, startTime, correlationId);
        log.error("{}", formattedLog);
    }

    /** format the grafana logger message and convert to JSON */ 
    
    private String formatLog( String errorType, String status, String errorCode, Instant startTime, String correlationId) {
    	
        LogEntry logEntry = new LogEntry();
    	Instant endTime = Instant.now(); 
        logEntry.setStartTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(Date.from(startTime)));
        logEntry.setEndTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(Date.from(endTime)));
        logEntry.setErrorClassification(status);
        if(errorType.toString().trim().isEmpty()) {
        	logEntry.setErrorType("info");
        	logEntry.setStatusCode("0000");
        } else {
        	logEntry.setErrorType("error");
        	logEntry.setStatusCode(errorCode);
        }
        logEntry.setFunctionalMap(grafanaConfig.getFunctionalMap());
        logEntry.setInterfaceMap(grafanaConfig.getInterfaceMap());
        logEntry.setRequestType(grafanaConfig.getRequestType());
        logEntry.setServiceId(grafanaConfig.getServiceId());
        logEntry.setSubSystem(grafanaConfig.getSubSystem());
        logEntry.setType(grafanaConfig.getType());
        logEntry.setTimeStampLog(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date()));
        logEntry.setMsgUid(correlationId);
        logEntry.setClientIp(" ");
        logEntry.setExecutionTimeMilliseconds(endTime.toEpochMilli() - startTime.toEpochMilli());

        return gson.toJson(logEntry);
    }
} 
