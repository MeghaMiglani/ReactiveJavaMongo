package casa.trans.mongo.enquiry.log;

import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.lang.reflect.Type;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import static java.time.ZoneOffset.UTC;

public class InstantSerializer implements JsonSerializer<Instant> {

    private static final String TIMESTAMP_PATTERN = "yyyy-MM-dd HH:mm:ss,SSS";

    @Override
    public JsonElement serialize(Instant instant, Type type, JsonSerializationContext jsonSerializationContext) {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter
                .ofPattern(TIMESTAMP_PATTERN)
                .withZone(UTC);
        return new JsonPrimitive(dateTimeFormatter.format(instant));
    }
}
