package casa.trans.mongo.enquiry.log;

import com.google.gson.annotations.SerializedName;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LogEntry {

	@SerializedName(value = "START_TIME")
	private String startTime;
	
	@SerializedName(value = "END_TIME")
    private String endTime;
	
	@SerializedName(value = "serviceID")
	private String serviceId;
	
	@SerializedName(value = "sub_system")
	private String subSystem;
	
	@SerializedName(value = "type")
	private String type;
	
	@SerializedName(value = "statusCode")
	private String statusCode;
	
	@SerializedName(value = "msg_uid")
	private String msgUid;
	
	@SerializedName(value = "client_ip")
	private String clientIp;
	
	@SerializedName(value = "error_classification")
	private String errorClassification;
	
	@SerializedName(value = "execution_time_milliseconds")
	private long executionTimeMilliseconds;
	
	@SerializedName(value = "interface_map")
	private String interfaceMap;
	
	@SerializedName(value = "functional_map")
	private String functionalMap;
	
	@SerializedName(value = "error_type")
	private String errorType;
	
	@SerializedName(value = "timestamp_log")
	private String timeStampLog;
	
	@SerializedName(value = "request_type")
	private String requestType;
}
