/*==========================================================================================*/
/* Program Title	: Transaction Enquiry Of All Systems - DQ AN CA           				*/
/* @Author			: Sreenivasa Sama / Megha Miglani                       				*/
/* @Date Written	: 19-08-2021										    				*/
/* @Function		: Transaction Details Enquiry through mongo DB 	Database            	*/
/* @HTTP Operation  : POST / GET     														*/
/* @Endpoint		:                                                                       */
/*==========================================================================================*/
/*  @Amendments                                                             				*/
/*==========================================================================================*/
package casa.trans.mongo.enquiry.model;

import java.math.BigDecimal;
import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Document(collection = "#{@mongoDbCollectionName}")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransactionDetails {
	
	@Id
	private String _id;	
	private String accountType; 	
	private String currencyCode;
	private String accountNumber;	
	private String fileSequenceNumber;
	private Date transactionDate;
	private Date postingDate;
	private String accountDisplayFormat;
    private String branchOfTransaction;
    private String tellerId;
    private String officerID;
    private String systemId;
    private String transactionTime;
    private Date valueDate;
    private String transactionAmountSign; 
    private BigDecimal transactionAmount;
    private Integer currencyDecimal;
    private String transactionReference;
    private String transactionCode;
    private String transCodeOriginal;
    private String clientReference;
    private String additionalReference;
    private String miscallaneousReference;
    private String bodIndicator;
    private String recordSource;
    private String deleteIndicator;
    private String caStatementCode;
    private String caErrorCorrectionIndicator;
    private String caValidTransactionIndicator;
    private String caTerminalType;
    private String caTransactionReasonCode;
    private String caNewLedgerSign; 
    private String caNewLedger;
    private String caChequeUpdateIndicator;
    private String dqTransactionSourceIndicator;
    private String dqTransactionClearningIndicator;
    private String dqTransactionLastBalanceSign;
    private BigDecimal dqTransactionLastBalance;
    private String dqTransactionMode;
    private String dqTransactionReasonCode;
    private String dqTransactionProductIndicator;
    private String anTransactionBatchTransFlag;
    private String anMcaAccountNumber;
    
}
