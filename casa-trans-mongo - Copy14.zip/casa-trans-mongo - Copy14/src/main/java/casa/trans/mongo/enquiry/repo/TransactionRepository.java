/*==========================================================================================*/
/* Program Title	: Transaction Enquiry Of All Systems - DQ AN CA           				*/
/* @Author			: Sreenivasa Sama / Megha Miglani                       				*/
/* @Date Written	: 19-08-2021										    				*/
/* @Function		: Transaction Details Enquiry through mongo DB 	Database            	*/
/* @HTTP Operation  : POST / GET     														*/
/* @Endpoint		:                                                                       */
/*==========================================================================================*/
/*  @Amendments                                                             				*/
/*==========================================================================================*/
package casa.trans.mongo.enquiry.repo;

import java.util.Date;

import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;

import casa.trans.mongo.enquiry.model.TransactionDetails;
import reactor.core.publisher.Flux;

@Repository
public interface TransactionRepository extends ReactiveMongoRepository<TransactionDetails, String> {
	
	/** Query for AN , CA and DQ without valid transaction indicator */ 
	
	@Query(value = "{$and:[{'accountType' : '?0',  "
			+ " 'accountNumber' : '?1', "
			+ " 'currencyCode'  : '?2', " 
	    	+ " 'transactionDate' : {$gte : ?3 , $lte : ?4}}]}")

	
	        Flux<TransactionDetails> findTransactionDetailsByAccountNumberAndTransactionDateInRange(
			String accountType,
			String accountNumber, 
			String currencyCode, 
			Date fromDate,
			Date toDate, 
			Pageable pageable);
	
//	/** Query for CA with valid transaction indicator */ 
//	
//	@Query(value = "{$and:[{'accountType' : '?0',  "
//			+ " 'currencyCode'  : '?2', " 
//			+ " 'accountNumber' : '?3', "
//			+ " 'caValidTransactionIndicator' : '?6'},"
//	    	+ " {$or:[{'postingDate' : {$gte : ?4 , $lte : ?5}}, {'transactionDate' : {$gte : ?4 , $lte : ?5}}]}]}" 
//			, sort = ("{transactionDate : -1 , fileSequenceNumber : -1 }"))
//	
//	        Flux<TransactionDetails> findCaTransactionDetailsByAccountNumberAndTransactionDateInRange(
//			String accountType,
//			String accountNumber, 
//			String currencyCode, 
//			Date fromDate,
//			Date toDate, 
//			String caValidTransactionIndicator,
//			Pageable pageable
//			);
}
