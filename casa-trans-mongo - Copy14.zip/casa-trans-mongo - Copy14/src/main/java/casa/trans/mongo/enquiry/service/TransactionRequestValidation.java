package casa.trans.mongo.enquiry.service;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

import org.apache.commons.lang3.ArrayUtils;
import org.springframework.http.HttpStatus;

import casa.trans.mongo.enquiry.domain.Request;
import casa.trans.mongo.enquiry.exception.BadRequestException;
import casa.trans.mongo.enquiry.exception.RestError;

public class TransactionRequestValidation {

	private static final String NUMERIC_REGEX = "[0-9]+";
	private static final String ALPHA_REGEX = "[A-Z]+";
	private static final String[] VALID_ACCOUNT_TYPE = { "CA_DBS", "CA_POSB", "DQ_DBS", "DQ_POSB", "AN_DBS" };

	public void validate(Request request, Instant startTime, String correlationId) {

		if (!ArrayUtils.contains(VALID_ACCOUNT_TYPE, request.getAccountType())) {
			RestError restError = new RestError(HttpStatus.BAD_REQUEST, "0001", "VALIDATION_ERROR",
					"Not a valid account type", correlationId, LocalDateTime.now(ZoneOffset.UTC));
			throw new BadRequestException(restError, startTime);
		}

		if (!(request.getAccountNumber().trim().matches(NUMERIC_REGEX))) {
			RestError restError = new RestError(HttpStatus.BAD_REQUEST, "0002", "VALIDATION_ERROR",
					"Not a valid account Number " + request.getAccountNumber(), correlationId, LocalDateTime.now(ZoneOffset.UTC));
			throw new BadRequestException(restError, startTime);
		}

		if ((request.getAccountNumber().trim().length() != 13 && request.getAccountNumber().trim().length() != 14)) {
			RestError restError = new RestError(HttpStatus.BAD_REQUEST, "0003", "VALIDATION_ERROR",
					"Not a valid account Number " + request.getAccountNumber(), correlationId, LocalDateTime.now(ZoneOffset.UTC));
			throw new BadRequestException(restError, startTime);
		}

		if (request.getCurrencyCode().trim().length() != 3) {
			RestError restError = new RestError(HttpStatus.BAD_REQUEST, "0004", "VALIDATION_ERROR",
					"Not a valid currency code " + request.getCurrencyCode(), correlationId, LocalDateTime.now(ZoneOffset.UTC));
			throw new BadRequestException(restError, startTime);
		}

		if (!request.getCurrencyCode().toUpperCase().matches(ALPHA_REGEX)) {
			RestError restError = new RestError(HttpStatus.BAD_REQUEST, "0005", "VALIDATION_ERROR",
					"Not a valid currency code " + request.getCurrencyCode(), correlationId, LocalDateTime.now(ZoneOffset.UTC));
			throw new BadRequestException(restError, startTime);
		}

		if (request.getToDate().before(request.getFromDate())) {
			RestError restError = new RestError(HttpStatus.BAD_REQUEST, "0006", "VALIDATION_ERROR",
					"From date is greater than to date", correlationId, LocalDateTime.now(ZoneOffset.UTC));
			throw new BadRequestException(restError, startTime);
		}

		
		if (request.getCountPerPage() <= 0) {
			RestError restError = new RestError(HttpStatus.BAD_REQUEST, "0007", "VALIDATION_ERROR",
					"Invalid count per page", correlationId, LocalDateTime.now(ZoneOffset.UTC));
			throw new BadRequestException(restError, startTime);
		}

		if (request.getPageNumber() < 0) {
			RestError restError = new RestError(HttpStatus.BAD_REQUEST, "0008", "VALIDATION_ERROR",
					"Invalid page number", correlationId, LocalDateTime.now(ZoneOffset.UTC));
			throw new BadRequestException(restError, startTime);
		}

	}
}