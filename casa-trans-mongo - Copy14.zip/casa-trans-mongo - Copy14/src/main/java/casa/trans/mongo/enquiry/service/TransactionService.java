/*==========================================================================================*/
/* Program Title	: Transaction Enquiry Of All Systems - DQ AN CA           				*/
/* @Author			: Sreenivasa Sama / Megha Miglani                       				*/
/* @Date Written	: 19-08-2021										    				*/
/* @Function		: Transaction Details Enquiry through mongo DB 	Database            	*/
/* 					  /issued/returned/stopped							    				*/
/* @HTTP Operation  : POST / GET     														*/
/* @Endpoint		:                                                                       */
/*==========================================================================================*/
/*  @Amendments                                                             				*/
/*==========================================================================================*/
package casa.trans.mongo.enquiry.service;

import java.time.Instant;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import casa.trans.mongo.enquiry.constants.Constants;
import casa.trans.mongo.enquiry.domain.Request;
import casa.trans.mongo.enquiry.domain.ResponseBody;
import casa.trans.mongo.enquiry.model.TransactionDetails;
import casa.trans.mongo.enquiry.repo.TransactionRepository;
import casa.trans.mongo.enquiry.utils.TransMongoUtils;
import reactor.core.publisher.Flux;

@Service

public class TransactionService {

	private int pageNumber;
	private int countPerPage; 

	@Autowired
	TransactionRepository transactionRepository;

	@Autowired
	TransMongoUtils transMongoUtils;

	/*
	 * getting all transaction details on basis of account number and Transaction
	 * Dates
	 */
	public Flux<ResponseBody> getTransDetailsWithInDateRange(Request request, Instant startTime, String correlationId) {

		TransactionRequestValidation transactionRequestValidation = new TransactionRequestValidation();
		transactionRequestValidation.validate(request, startTime, correlationId);
		
		Flux<TransactionDetails> transDetailsFlux;
		this.pageNumber = request.getPageNumber();
		this.countPerPage = request.getCountPerPage(); 
		Pageable pageable = PageRequest.of(this.pageNumber, this.countPerPage);
		
		/** Calling CA query using valid transaction indicator 1 , 
		 * default query for AN and DQ do not have valid transaction indicator */ 
		
//		if (request.getAccountType().contentEquals(Constants.CA_DBS) || 
//				request.getAccountType().contentEquals(Constants.CA_POSB)) {
//			transDetailsFlux = transactionRepository.findCaTransactionDetailsByAccountNumberAndTransactionDateInRange(
//					request.getAccountType(), request.getAccountNumber(), request.getCurrencyCode(),
//					transMongoUtils.formatDateInUTC(request.getFromDate()),
//					transMongoUtils.formatDateInUTC(request.getToDate()), "1", pageable);
//		} else {
			transDetailsFlux = transactionRepository.findTransactionDetailsByAccountNumberAndTransactionDateInRange(
					request.getAccountType(), request.getAccountNumber(), request.getCurrencyCode(),
					transMongoUtils.formatDateInUTC(request.getFromDate()),
					transMongoUtils.formatDateInUTC(request.getToDate()), pageable);
//		}
		
		Flux<ResponseBody> transDetailsResponseFlux = transDetailsFlux.map(item -> {
			ResponseBody responseBody = new ResponseBody();
			return populateResponseBodyDetails(responseBody, item);
		});

		return transDetailsResponseFlux;
	}

	/** Mapping flux of TransDetails into flux of ResponseBody */
	
	private ResponseBody populateResponseBodyDetails(ResponseBody responseBody, TransactionDetails transDetails) {
		responseBody.setAccountType(transDetails.getAccountType());
		responseBody.setCurrencyCode(transDetails.getCurrencyCode());
		responseBody.setAccountNumber(transDetails.getAccountNumber());
		responseBody.setFileSequenceNumber(transDetails.getFileSequenceNumber());
		responseBody.setTransactionDate(transDetails.getTransactionDate());
		responseBody.setPostingDate(transDetails.getPostingDate());

		responseBody.setBranchOfTransaction(transDetails.getBranchOfTransaction());
		responseBody.setTransactionTime(transDetails.getTransactionTime());
		responseBody.setValueDate(transDetails.getValueDate());
		responseBody.setTransactionAmount(transMongoUtils.formatAmount(transDetails.getTransactionAmount(),
				transDetails.getCurrencyDecimal(), transDetails.getTransactionAmountSign()));
		responseBody.setCurrencyDecimal(transDetails.getCurrencyDecimal().toString());
		responseBody.setTransactionReference(transDetails.getTransactionReference());
		responseBody.setTransactionCodeOriginal(transDetails.getTransCodeOriginal());
		responseBody.setTransactionCode(transDetails.getTransactionCode());

		responseBody.setReference1(transDetails.getClientReference());
		responseBody.setReference2(transDetails.getAdditionalReference());
		responseBody.setReference3(transDetails.getMiscallaneousReference());
		responseBody.setStatementCode(transDetails.getCaStatementCode());
		responseBody.setClearingIndicator(transDetails.getDqTransactionClearningIndicator());
		responseBody.setSystemId(transDetails.getSystemId());
		responseBody.setErrorCorrectionIndicator(transDetails.getCaErrorCorrectionIndicator());
		responseBody.setValidTransactionIndicator(transDetails.getCaValidTransactionIndicator());

		responseBody.setPageNumber(this.pageNumber);
		responseBody.setCountPerPage(this.countPerPage);
		responseBody.setLastKey(transDetails.getAccountType().trim() + ":" + transDetails.getCurrencyCode().trim() + ":"
				+ transDetails.getAccountNumber().trim() + ":" + transDetails.getFileSequenceNumber().trim() + ":"
				+ transMongoUtils.dateToInteger(transDetails.getTransactionDate()) + ":"
				+ transMongoUtils.dateToInteger(transDetails.getPostingDate()));

		return responseBody;
	}

}