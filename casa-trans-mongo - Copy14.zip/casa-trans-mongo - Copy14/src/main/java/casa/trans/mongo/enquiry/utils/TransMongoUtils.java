package casa.trans.mongo.enquiry.utils;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.lang.Math;

import org.springframework.stereotype.Component;

@Component
public class TransMongoUtils {

	public TransMongoUtils() {

	}

	public Date formatDateInUTC(Date date) {
		 
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String inputDateTime = formatter.format(date);
		inputDateTime = inputDateTime + " 00:00:00";
		DateTimeFormatter DATE_WITH_TIMEZONE_PATTERN = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
	
		LocalDateTime dateTime = LocalDateTime.parse(inputDateTime, DATE_WITH_TIMEZONE_PATTERN);
		ZonedDateTime localZonedDateTime = dateTime.atZone(ZoneOffset.UTC);
		Date date2 = Date.from(localZonedDateTime.toInstant());
		return date2;
	}

	public BigDecimal formatAmount(BigDecimal amount, double currencyDecimal, String sign) {

		BigDecimal amountDivisor = new BigDecimal(Math.pow(10.0, currencyDecimal));
		if (sign.trim().contentEquals("+"))
			return amount.divide(amountDivisor);
		else
			return new BigDecimal(-1).multiply(amount.divide(amountDivisor));
	}

	public Integer dateToInteger(Date date) {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
		return Integer.valueOf(formatter.format(date));
	}

	public Date stringToDate(String dateString) throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
		return formatter.parse(dateString);
	}

	public Date tMinus2ToDate(Date toDate) {
		return toDate;
	}

	public String[] fetchLastKeyDetails(String cursorId) {
		String lastKeyDetails[] = cursorId.split(":");
		return lastKeyDetails;
	}

}
